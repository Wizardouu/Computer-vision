import streamlit as st
import tensorflow as tf
import numpy as np
from keras.src.applications.mobilenet_v2 import MobileNetV2
from tensorflow.keras.preprocessing import image as keras_image
from PIL import Image, ImageOps
from tensorflow.keras.regularizers import l2

# Load the model once and cache it for reuse
@st.cache_resource
def load_model():
    IMG_SHAPE = (224, 224, 3)
    base_model = MobileNetV2(input_shape=IMG_SHAPE, include_top=False, weights='imagenet')
    base_model.trainable = True

    # Define the model
    model = tf.keras.Sequential([
        tf.keras.layers.InputLayer(input_shape=IMG_SHAPE),
        base_model,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dense(256, activation='relu', kernel_regularizer=l2(0.01)),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(128, activation='relu', kernel_regularizer=l2(0.01)),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(7, activation='softmax', kernel_regularizer=l2(0.01))
    ])

    # Load the saved weights
    model.load_weights("C:\\Users\\ADMIN\\Downloads\\week2\\o.weights.h5")
    model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=0.001, momentum=0.9),
                  loss=tf.keras.losses.CategoricalCrossentropy(from_logits=False),
                  metrics=['accuracy'])
    return model

model = load_model()

# Define class names
class_names = ["CaS", "CoS", "Gum", "MC", "OC", "OLP", "OT"]

# Function to predict class from image
def predict_class(uploaded_img):
    # Convert grayscale images to RGB
    # Resize the image to the input shape of the model
    img = uploaded_img.resize((224, 224))

    # Convert the image to a numpy array
    img_array = np.array(img)

    # Add a batch dimension to the image array
    img_array = np.expand_dims(img_array, axis=0)

    # Predict the class
    predictions = model.predict(img_array)
    predicted_label = class_names[np.argmax(predictions, axis=1)[0]]
    return predicted_label


# Streamlit UI
st.title('Teeth Diagnosis Web App')
st.write("Upload a teeth image to diagnose.")

# File uploader
uploaded_file = st.file_uploader("Choose a teeth image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    uploaded_img = Image.open(uploaded_file)  # Changed variable name
    st.image(uploaded_img, caption='Uploaded Teeth Image.', use_column_width=True)
    st.write("")
    st.write("Classifying...")

    diagnosis = predict_class(uploaded_img)  # Updated to match the new variable name
    st.success(f"Diagnosis: {diagnosis}")
