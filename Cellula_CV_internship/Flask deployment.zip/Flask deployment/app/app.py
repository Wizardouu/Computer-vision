import os
import numpy as np
import matplotlib.pyplot as plt
from flask import Flask, request, redirect, render_template_string, send_file
import tifffile as tiff  # Library to read .tif files
from sklearn.preprocessing import MinMaxScaler
from PIL import Image
import io
import base64
import tensorflow as tf

# Initialize Flask app
app = Flask(__name__)

# Folder to store uploaded images
UPLOAD_FOLDER = 'static/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load your model (ensure your model path is correct)
model = tf.keras.models.load_model("C:\\Users\\ADMIN\\Downloads\\trial_model3.h5")

# Preprocess the .tif image to the required format
def preprocess_tif_image(image_path, target_size=(128, 128)):
    image = tiff.imread(image_path)
    
    # Check if the image has more than 3 channels, and extract the first 3 (RGB) channels if needed
    if image.shape[-1] > 3:
        image = image[:, :, 1:4]  # Keep only the first 3 channels (RGB)
    
    # Reshape to match model input dimensions
    image = image.reshape(1, 128, 128, 3)

    return image

# Post-process prediction (segmentation mask)
def postprocess_mask(predictions, threshold=0.5):
    if predictions.shape[-1] > 1:
        predicted_mask = np.argmax(predictions, axis=-1)
    else:
        predicted_mask = (predictions > threshold).astype(np.uint8)
    return np.squeeze(predicted_mask)

# Route to render HTML page for image upload
@app.route('/')
def index():
    return render_template_string('''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Image Segmentation</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f5;
                color: #333;
                text-align: center;
            }
            h1 {
                color: #4CAF50;
                font-size: 48px;
                margin-top: 20px;
            }
            h2 {
                color: #333;
                font-size: 24px;
            }
            form {
                margin-top: 30px;
            }
            input[type="file"] {
                font-size: 18px;
                padding: 10px;
                margin: 20px auto;
                display: block;
            }
            input[type="submit"] {
                font-size: 20px;
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 12px 20px;
                cursor: pointer;
                border-radius: 5px;
                transition: background-color 0.3s;
            }
            input[type="submit"]:hover {
                background-color: #45a049;
            }
            .container {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
                height: 100vh;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Image Segmentation</h1>
            <h2>Upload a .tif Image to Generate a Segmentation Mask</h2>
            <form action="/predict" method="POST" enctype="multipart/form-data">
                <input type="file" name="file" accept="image/tif" required>
                <input type="submit" value="Predict Segmentation">
            </form>
        </div>
    </body>
    </html>
    ''')

# Route to handle image upload and prediction
@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)

    if file:
        # Save the uploaded file
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        # Preprocess the image for the model
        input_image = preprocess_tif_image(file_path)

        # Run prediction
        predictions = model.predict(input_image)

        # Post-process the mask
        mask = postprocess_mask(predictions)

        # Convert mask to image format
        mask_image = Image.fromarray((mask * 255).astype(np.uint8))  # Convert mask to 0-255 scale

        # Convert the mask image to a format that can be embedded in HTML (base64)
        buffered = io.BytesIO()
        mask_image.save(buffered, format="PNG")
        mask_base64 = base64.b64encode(buffered.getvalue()).decode()

        # Return HTML with the predicted mask embedded
        return render_template_string(f'''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Segmentation Result</title>
        </head>
        <body style="text-align: center;">
            <h1>Predicted Segmentation Mask</h1>
            <img src="data:image/png;base64,{mask_base64}" alt="Predicted Mask" style="border: 2px solid black; width: 50%;"/>
            <br><br>
            <a href="/">Upload Another Image</a>
        </body>
        </html>
        ''')

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
